rm -rf x/cust
rm -rm x/META-INF
cp -r META-INF x/